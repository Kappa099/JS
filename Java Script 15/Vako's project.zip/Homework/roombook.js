

let chidleft = document.querySelector(".chidleft")
let roomarray = []

let roomId = new URLSearchParams(window.location.search).get("id")
console.log("Room ID:", roomId)

let roomPrice = 0
let form = document.querySelector(".reservation-card")



let inpChackin = document.querySelector(".inpChackin")
let inpChackOut = document.querySelector(".inpChackOut")
let inpName = document.querySelector(".inpName")
let inpPhone = document.querySelector(".inpPhone")



fetch(`https://hotelbooking.stepprojects.ge/api/Rooms/GetRoom/${roomId}`)
  .then(resp => resp.json())
  .then(room => {
    renderproduct(room)
  })

  function renderproduct(room) {
    console.log(room)
    roomPrice = room.pricePerNight
    
    let carouselItemsHTML = ""
    room.images.forEach((image, index) => {
        carouselItemsHTML += `
            <div class="carousel-item ${index === 0 ? 'active' : ''}">
                <img src="${image.source}" class="d-block w-100" alt="Room Image ${index + 1}">
            </div>`
    })

    chidleft.innerHTML = `
        <div id="carousel-room" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                ${carouselItemsHTML}
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carousel-room" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carousel-room" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>`
}


form.addEventListener("submit", function(e){
        e.preventDefault()
        let postObj = {
          roomID: Number(roomId),
          checkInDate : inpChackin.value,
          checkOutDate : inpChackOut.value,
          totalPrice : roomPrice,
          isConfirmed: true,
          customerName : inpName.value,
          customerId : "123", 
          customerPhone : inpPhone.value
        }
  fetch("https://hotelbooking.stepprojects.ge/api/Booking", {
    method : "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body : JSON.stringify(postObj)

  })
  .then(resp => {
    console.log(resp)
    if(resp.status == 200){
        alert("Booked succsefull")
    }
    else{
        alert("Cound not Book")
    }
  })
  .catch(er => alert(er))
  

})
